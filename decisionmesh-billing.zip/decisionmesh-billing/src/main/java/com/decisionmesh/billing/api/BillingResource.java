package com.decisionmesh.billing.api;

import com.decisionmesh.billing.service.StripeService;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.Map;

@Path("/billing")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class BillingResource {

    @Inject
    StripeService stripeService;

    @POST
    @Path("/checkout")
    public Response createCheckout(Map<String, String> request) throws Exception {
        String customerId = request.get("customerId");
        String priceId = request.get("priceId");

        String url = stripeService.createCheckoutSession(customerId, priceId);

        return Response.ok(Map.of("url", url)).build();
    }
}