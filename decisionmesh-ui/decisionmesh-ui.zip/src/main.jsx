import React, { useEffect } from 'react';
import ReactDOM from 'react-dom/client';
import { ReactKeycloakProvider, useKeycloak } from '@react-keycloak/web';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter } from 'react-router-dom';
import keycloakInstance from './auth/keycloak';
import { ProjectProvider } from './context/ProjectContext';
import { BrandingProvider } from './context/BrandingContext';
import { CreditProvider } from './context/CreditContext';
import App from './App';
import LandingPage from './pages/LandingPage';
import './index.css';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30_000,
      retry: (count, err) => {
        const status = err?.response?.status;
        if (status >= 400 && status < 500) return false;
        return count < 2;
      },
    },
  },
});

const initOptions = {
  onLoad: 'check-sso',
  pkceMethod: 'S256',
  checkLoginIframe: false,
};

function FullScreenSpinner() {
  return (
    <div style={{
      height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: '#08080a',
    }}>
      <div style={{
        width: 32, height: 32,
        border: '2px solid rgba(37,99,235,0.3)',
        borderTopColor: '#2563eb',
        borderRadius: '50%',
        animation: 'spin 0.8s linear infinite',
      }} />
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

function AppWrapper() {
  const { keycloak, initialized } = useKeycloak();

  useEffect(() => {
    if (!initialized || !keycloak.authenticated) return;
    const interval = setInterval(() => {
      // Silent refresh only — do NOT call keycloak.login() on failure.
      // If the backend is returning 401 for reasons other than token expiry
      // (e.g. email_verified: false), calling login() here causes an infinite
      // redirect loop: Keycloak redirects back immediately because the session
      // is still valid, and the cycle repeats. Individual request failures are
      // handled gracefully in api.js without triggering redirects.
      keycloak.updateToken(70).catch(() => {});
    }, 60_000);
    return () => clearInterval(interval);
  }, [initialized, keycloak]);

  // Keycloak still initialising — show spinner
  if (!initialized) return <FullScreenSpinner />;

  // Not authenticated → show marketing landing page
  if (!keycloak.authenticated) return <LandingPage />;

  // Authenticated → render app immediately.
  // Contexts (Branding, Project, Credit) load their data in the background.
  // We deliberately do NOT gate on their loading states: if the backend is
  // returning 401s the contexts may be stuck, and blocking here would prevent
  // the user from navigating to /debug/token to diagnose the issue.
  return (
    <BrandingProvider keycloak={keycloak}>
      <ProjectProvider keycloak={keycloak}>
        <CreditProvider keycloak={keycloak}>
          <App keycloak={keycloak} />
        </CreditProvider>
      </ProjectProvider>
    </BrandingProvider>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <ReactKeycloakProvider authClient={keycloakInstance} initOptions={initOptions}>
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <AppWrapper />
      </BrowserRouter>
    </QueryClientProvider>
  </ReactKeycloakProvider>
);
